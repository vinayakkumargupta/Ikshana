package com.example.ikshana6;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Colorblindness extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_colorblindness);
    }
}